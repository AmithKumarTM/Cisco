
public class TCS extends TataGroup{
	
	public void getCeoName(){
		System.out.println("Rajesh Gopinathan is the CEO of TCS");
		super.getCeoName();
	}
	
	public static void main(String args[]){
		TataGroup t = new TCS();
		t.getCeoName();
	}
}
