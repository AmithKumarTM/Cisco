
public class TataGroup {

	public void getCeoName(){
		System.out.println("N.Chandrashekaran is the CEO of Tata Group");
	}
}
