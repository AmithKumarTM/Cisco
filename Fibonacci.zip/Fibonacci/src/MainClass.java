
public class MainClass {

	public static void main(String args[]){
		int limit = 10;
		int n0 = 1,n1 = 1,n2;
		
		System.out.print(n0+" "+n1);
		while(limit>0){
			n2 = n0+n1;
			n0 = n1;
			n1 = n2;
			limit--;
			System.out.print(" "+n2);
		}
	}
}
