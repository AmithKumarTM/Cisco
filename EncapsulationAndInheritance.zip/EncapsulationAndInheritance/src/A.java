
public class A {

	int i = 10;
	
	public void dispaly(){
		System.out.println("This is Class A");
	}
}
