
public class B extends A{

	int j = 20;
	
	public void dispaly(){
		System.out.println("This is Class B");
	}
}
