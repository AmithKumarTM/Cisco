
public class MainClass {

	public static void main(String args[]){
		C obj = new C();
		
		System.out.println("i value is "+obj.i);
		System.out.println("j value is "+obj.j);
		System.out.println("k value is "+obj.k);
	}
}
