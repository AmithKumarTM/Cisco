
public class C extends B{

	int k = 30;
	
	public void dispaly(){
		System.out.println("This is Class C");
	}
}
