
public class MainClass {

	public static void main(String args[]){
		int n = 356;
		int sum = 0;
		int r;
		int temp = n;
		
		while(n>0){
			r = n%10;
			sum+=r;
			n/=10;
		}
		System.out.println("Sum of the digits of number "+temp+" is "+sum);
	}
}
