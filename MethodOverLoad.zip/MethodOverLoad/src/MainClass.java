
public class MainClass {

	public void sum(int a, int b){
		System.out.println(a+b);
	}
	
	public void sum(double a, double b){
		System.out.println(a+b);
	}
	
	public void sum(int a, int b, int c){
		System.out.println(a+b+c);
	}
	
	public static void main(String args[]){
		MainClass mainClass  = new MainClass();
		mainClass.sum(10, 20);
		mainClass.sum(5.5, 60.5);
		mainClass.sum(5, 1, 4);
	}
}
