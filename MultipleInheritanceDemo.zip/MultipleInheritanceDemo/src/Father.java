
public interface Father {

	public void educate();
}
