
public class Child implements Father,Mother{

	public void educate() {
		// TODO Auto-generated method stub
		System.out.println(Father.class+" Thanks for educating me");
		System.out.println(Mother.class+" Thanks for educating me");
	}

	public static void main(String args[]){
		Child c = new Child();
		c.educate();
	}
}
