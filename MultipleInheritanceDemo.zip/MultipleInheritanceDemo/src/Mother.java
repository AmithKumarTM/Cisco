
public interface Mother {

	public void educate();
}
