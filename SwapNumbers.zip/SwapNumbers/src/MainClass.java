
public class MainClass {
	
	public void swapNumbers(int x,int y){
		x = x^y;
		y = y^x;
		x = x^y;
		
		System.out.println("After Swapping");
		System.out.println("X is "+x+" Y is "+y);
	}
	
	public static void main(String args[]){
		int x = 10;
		int y = 20;
		MainClass mainClass = new MainClass();
		
		System.out.println("Before Swapping");
		System.out.println("X is "+x+" Y is "+y);
		mainClass.swapNumbers(x, y);
	}
}
